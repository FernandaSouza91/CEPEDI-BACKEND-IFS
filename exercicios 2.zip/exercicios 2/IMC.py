peso=float(input('Digite o seu peso '))
altura=float(input('Digite sua altura '))
IMC = peso/(altura*altura)
if IMC <18.5:
    print('Abaixo do peso')
elif IMC >= 18.9 and IMC <= 24.9:
    print('Peso ideal')
elif IMC >= 25 and IMC <= 29.9:
    print('Levemente acima do peso')
elif IMC >=30 and IMC <= 34.9:
    print('Obesidade Grau I')
elif IMC >= 35 and IMC <= 39.9:
    print('Obesidade grau II(severa)')
elif IMC >= 40:
    print('Obesidade grau III(mórbida)')