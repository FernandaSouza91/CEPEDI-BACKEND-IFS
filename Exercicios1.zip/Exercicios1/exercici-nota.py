'''Faça um programa que leia as duas notas de um aluno em uma matéria e mostre na tela a sua média na disciplina
com a mensagem: “A média entre [nota1] e [nota2] é igual a [média].'''

nota1=float(input('Digite a primeira nota '))
nota2=float(input('Digite a segunda nota'))
media = (nota1 + nota2 )/2
print(f"A média entre {nota1} e {nota2} é igual a {media}")





